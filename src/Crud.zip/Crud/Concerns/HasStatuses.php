<?php 
namespace Core\Crud\Concenrs;

trait HasStatuses
{
	
}