<?php return [
	'statuses' => [
		'draft' 		=> 'armin::statuses.draft', 
		'scheduled'		=> 'armin::statuses.scheduled', 
		'published' 	=> 'armin::statuses.published',
		'unpublished' 	=> 'armin::statuses.unpublished',
		'archived' 		=> 'armin::statuses.archived', 
		'removed' 		=> 'armin::statuses.removed',   
		'blocked' 		=> 'armin::statuses.blocked', 
		'pending' 		=> 'armin::statuses.pending',
		'activated'		=> 'armin::statuses.activated',
		'deactivated'	=> 'armin::statuses.deactivated',  
		'blocked'		=> 'armin::statuses.blocked',  
		'banned'		=> 'armin::statuses.banned',  
	],
];