<p class="{{ array_pull($wrapper_attributes, 'class', 'inline-label button-height') }}" 
	{{ Html::attributes($wrapper_attributes) }}> 
	{!! $slot !!}  
</p>
 