@if(! empty(trim($slot)))
<span class="info-spot right"> 
	<span class="icon-info"></span> 
	<span class="info-bubble">{!! $slot !!}</span> 
</span> 
@endif