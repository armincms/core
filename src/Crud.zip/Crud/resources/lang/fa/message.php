<?php return [
	'resource_was_created' 	=> 'منبع ایجاد شد.', 
	'resource_was_saved' 	=> 'منبع ذخیره شد.', 
	'resource_was_updated' 	=> 'منبع بروزرسانی شد.',
	'resource_was_restored'	=> 'منبع بازگردانده شد.',
	'resource_was_deleted' 	=> 'منبع حذف شد.',
	'resource_was_destroyed'=> 'منبع به سطل زباله اتنقال یافت.',
	'successfully_saved'	=> 'با موقفیت ذخیره شد.',
];