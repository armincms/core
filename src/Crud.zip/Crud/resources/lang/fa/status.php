<?php return [ 
	'draft' 		=> 'پیشنویس', 
	'scheduled'		=> 'زمانبندی شده', 
	'published' 	=> 'منتشر شده',
	'unpublished' 	=> 'منتشر نشده',
	'archived' 		=> 'بایگانی شده', 
	'trashed' 		=> 'حذف شده',   
	'blocked' 		=> 'مسدود شده', 
	'pending' 		=> 'در انتظار تایید',
	'activated'		=> 'فعال',
	'deactivated'	=> 'غیرفعال',   
	'banned'		=> 'ممنوع شده',  
];