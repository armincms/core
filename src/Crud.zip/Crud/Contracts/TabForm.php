<?php 
namespace Core\Crud\Contracts;  

interface TabForm
{   
	public function getTitle();
	public function setTitle(String $title);
}

