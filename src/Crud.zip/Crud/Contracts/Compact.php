<?php 
namespace Core\Crud\Contracts;

interface Compact
{

}
