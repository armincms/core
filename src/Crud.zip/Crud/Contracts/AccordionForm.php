<?php 
namespace Core\Crud\Contracts;  

interface AccordionForm
{   
}
