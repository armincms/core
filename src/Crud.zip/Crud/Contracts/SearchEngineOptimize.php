<?php 
namespace Core\Crud\Contracts;


interface SearchEngineOptimize
{
	public function metaTitle();
	public function metaDescription();  
}