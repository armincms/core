<?php 
namespace Core\Crud\Events; 

class UnpublishedResource extends Event
{
    
}
