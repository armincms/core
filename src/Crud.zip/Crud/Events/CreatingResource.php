<?php 
namespace Core\Crud\Events; 

class CreatingResource extends Event
{ 
}
