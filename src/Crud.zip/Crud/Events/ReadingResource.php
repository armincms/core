<?php 
namespace Core\Crud\Events; 

class ReadingResource extends Event
{  
}
