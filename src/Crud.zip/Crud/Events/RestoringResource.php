<?php

namespace Core\Crud\Events;


class RestoringResource extends Event
{ 
}
