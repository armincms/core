<?php   
namespace Core\Crud\Events;


trait LoggableEvent
{ 

	 
}