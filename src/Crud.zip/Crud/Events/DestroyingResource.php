<?php 
namespace Core\Crud\Events;


class DestroyingResource extends Event
{ 
}
