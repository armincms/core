<?php

namespace Core\Crud\Events; 

class DestroyedResource extends Event
{ 
}
