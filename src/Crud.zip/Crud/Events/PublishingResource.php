<?php 
namespace Core\Crud\Events;
 
class PublishingResource Extends Event
{ 
}
