<?php 
namespace Core\Crud\Events;

class UpdatingResource extends Event
{ 
}
