<?php 
namespace Core\Crud\Events; 

class DeletingResource extends Event
{ 
}
