<?php 
namespace Core\Crud\Events;


class PublishedResource extends Event
{ 
}
