<?php

namespace Core\Crud\Events; 

class ReadResource extends Event
{ 
}
