<?php 
namespace Core\Crud\Events; 

class UnpublishingResource extends Event
{ 
}
