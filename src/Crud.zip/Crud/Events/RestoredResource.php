<?php

namespace Core\Crud\Events; 

class RestoredResource extends Event
{ 
}
