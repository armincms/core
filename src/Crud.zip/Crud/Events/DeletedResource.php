<?php 
namespace Core\Crud\Events; 

class DeletedResource extends Event
{ 
}
