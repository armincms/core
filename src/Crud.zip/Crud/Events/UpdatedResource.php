<?php 
namespace Core\Crud\Events;
 

class UpdatedResource extends Event
{
     
}
