<?php 
namespace Core\Crud\Events; 


class EditingResource extends Event
{ 
}
