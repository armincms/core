<?php 
namespace Core\Crud\Events; 

class CreatedResource extends Event
{
     
}
