<?php
namespace Core\Crud\Observers;

class ResourceObserver extends ExtendsName
{
    public function __construct()
    {
    }
}
