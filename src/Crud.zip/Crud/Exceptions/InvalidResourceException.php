<?php 
namespace Core\Crud\Exceptions;

use Symfony\Component\Console\Exception\RuntimeException;

class InvalidResourceException extends RuntimeException
{ 
}
