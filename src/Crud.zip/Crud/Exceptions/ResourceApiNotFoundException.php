<?php 
namespace Core\Crud\Exceptions;

use Symfony\Component\Console\Exception\RuntimeException;

class ResourceApiNotFoundException extends RuntimeException
{ 
}
